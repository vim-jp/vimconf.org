
これは名札を作成するために使用したファイルなどです。

* [VimConf 2014](http://vimconf.connpass.com/event/9168/)
* [名札の準備 #28](https://github.com/vim-jp/vimconf/issues/28)
* 名札の人数分印刷やcanvasで自動化した人: @rbtnn
* 名札の画像とか編集してくれた人: @raa0121, @supermomonga

