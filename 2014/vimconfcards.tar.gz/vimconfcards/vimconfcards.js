
function redraw(canvas, context, img01, img02, id){
    context.drawImage(img01, 0, 0, canvas.width, canvas.height);
    context.drawImage(img02, 30, 40, canvas.width / 5, canvas.width / 5);

    context.fillStyle = "rgb(0,0,0)";
    context.font = "16pt Arial";
    context.fillText(id, 30 + canvas.width / 5 + 30, canvas.height / 3);  

    context.fillStyle = "rgb(255,255,255)";
    context.font = "normal 20pt Audiowide";
    context.fillText("VimConf 2014", canvas.width / 10, canvas.height / 7 * 6);  

    context.fillStyle = "rgb(0,0,0)";
    context.font = "normal 7pt Audiowide";
    context.fillText("Sat Nov 8th 2014 in Tokyo, Japan", canvas.width / 7, canvas.height / 18 * 17);  
}

function add_card(id, img_src){
  var canvas = document.createElement('canvas'); 

  // A4�ň������Ɩ��D(���h)�Ƃقړ����ɂȂ�T�C�Y
  canvas.width = 320;
  canvas.height = 200;

  var objBody = document.getElementById("output"); 
  objBody.appendChild(canvas); 

  if (canvas.getContext) {
    var context = canvas.getContext('2d');
    context.beginPath();
    var img01 = new Image();
    img01.src = "./img/card_without_title.png";
    var img02 = new Image();
    img02.src = img_src;

    img01.onload = function(){
      redraw(canvas, context, img01, img02, id);
    }
    img02.onload = function(){
      redraw(canvas, context, img01, img02, id);
    }
    redraw(canvas, context, img01, img02, id);
  }
}

function draw_canvas(){
  var aNode = document.getElementById("output");
  for (var i = aNode.childNodes.length-1; i>=0; i--) {
    aNode.removeChild(aNode.childNodes[i]);
  }

  // ���\��
  add_card( "@ujm", "./img/participants/ujm.jpg");
  add_card( "@KoRoN", "./img/participants/KoRoN.jpg");
  add_card( "@ShougoMatsu", "./img/participants/ShougoMatsu.png");
  add_card( "@thinca", "./img/participants/thinca.png");
  add_card( "@Linda_pp", "./img/participants/Linda_pp.jpg");
  add_card( "@kamichidu", "./img/participants/kamichidu.png");
  add_card( "@deris0126", "./img/participants/deris0126.png");
  add_card( "@c0hama", "./img/participants/c0hama.bmp");
  add_card( "@pebble8888", "./img/participants/pebble8888.jpg");
  add_card( "@haya14busa", "./img/participants/haya14busa.png");
  add_card( "@Kuniwak", "./img/participants/Kuniwak.png");
  add_card( "@raa0121", "./img/participants/raa0121.png");
  add_card( "@supermomonga", "./img/participants/supermomonga.png");

  // ��ʎQ����
  add_card( "@rbtnn", "./img/participants/rbtnn.png");
  add_card( "@shiwano", "./img/participants/shiwano.png");
  add_card( "@yomi322", "./img/participants/yomi322.jpg");
  add_card( "@aomoriringo", "./img/participants/aomoriringo.jpg");
  add_card( "@hiroyukim", "./img/participants/hiroyukim.jpg");
  add_card( "@k_takata", "./img/participants/k_takata.gif");
  add_card( "@sierrarries", "./img/participants/sierrarries.jpg");
  add_card( "@dice_zu", "./img/participants/dice_zu.png");
  add_card( "@konnyakmannan", "./img/participants/konnyakmannan.jpg");
  add_card( "@KazuakiM", "./img/participants/KazuakiM.jpg");
  add_card( "@stvjbz", "./img/participants/stvjbz.jpg");
  add_card( "@yymm", "./img/participants/yymm.png");
  add_card( "@yoshiko", "./img/participants/yoshiko.jpg");
  add_card( "@thleap", "./img/participants/thleap.png");
  add_card( "@usaturn", "./img/participants/usaturn.png");
  add_card( "@Takuya.N", "./img/participants/Takuya.N.png");
  add_card( "@basyura", "./img/participants/basyura.png");
  add_card( "@alpaca_taichou", "./img/participants/alpaca_taichou.jpg");
  add_card( "@celt", "./img/participants/celt.jpg");
  add_card( "minakawa", "./img/participants/minakawa.jpg");
  add_card( "@tomozo16", "./img/participants/tomozo16.jpg");
  add_card( "@If_I_were_boxp", "./img/participants/If_I_were_boxp.png");
  add_card( "@nmasuko", "./img/participants/nmasuko.png");
  add_card( "@sunny_510", "./img/participants/sunny_510.png");
  add_card( "A_N", "./img/participants/A_N.jpg");
  add_card( "@creasty", "./img/participants/creasty.png");
  add_card( "@nocd5", "./img/participants/nocd5.png");
  add_card( "@yakisuzu", "./img/participants/yakisuzu.jpg");
  add_card( "@koara-local", "./img/participants/koara-local.jpg");
  add_card( "@minty_opera", "./img/participants/minty_opera.jpg");
  add_card( "@tonikaku", "./img/participants/tonikaku.png");
  add_card( "naoto_kashita", "./img/participants/naoto_kashita.jpg");
  add_card( "@mtwtk_man", "./img/participants/mtwtk_man.png");
  add_card( "@papix", "./img/participants/papix.jpg");
  add_card( "camel", "./img/participants/camel.gif");
  add_card( "Motonori Iwata", "./img/participants/Motonori Iwata.jpg");
  add_card( "koizuss", "./img/participants/koizuss.jpg");
  add_card( "@adsh1y0", "./img/participants/adsh1y0.png");
  add_card( "@guyon", "./img/participants/guyon.png");
  add_card( "yk_toumi", "./img/participants/yk_toumi.jpg");
  add_card( "@wiredool", "./img/participants/wiredool.gif");
  add_card( "@b4b4r07", "./img/participants/b4b4r07.jpg");
  add_card( "@hotoolong", "./img/participants/hotoolong.jpg");
  add_card( "@minodisk", "./img/participants/minodisk.png");
  add_card( "@tabe1hands", "./img/participants/tabe1hands.jpg");
  add_card( "@yoshikaw", "./img/participants/yoshikaw.png");
  add_card( "akiyosi", "./img/participants/akiyosi.png");
  add_card( "@seijiro_ozawa", "./img/participants/seijiro_ozawa.jpeg");
  add_card( "@yayoc", "./img/participants/yayoc.jpg");
  add_card( "@tttsuchiya", "./img/participants/tttsuchiya.jpg");
  add_card( "@tyochiai", "./img/participants/tyochiai.jpg");
  add_card( "@sempreff", "./img/participants/sempreff.gif");
  add_card( "mohammed", "./img/participants/mohammed.png");
  add_card( "@uochan", "./img/participants/uochan.png");
  add_card( "@kodam", "./img/participants/kodam.png");
  add_card( "@fatman_begins", "./img/participants/fatman_begins.jpg");
  add_card( "@ono_pm", "./img/participants/ono_pm.png");
  add_card( "ari0515", "./img/participants/ari0515.gif");
  add_card( "kuwa72", "./img/participants/KUWASHIMA Yuichiro.png");
  add_card( "@aliceinwire", "./img/participants/aliceinwire.png");

  // ���e��̂�
  add_card( "FuTaIchicoTukushi", "./img/participants/FuTaIchicoTukushi.jpg");

  // �L�����Z��
  add_card( "@K636174", "./img/participants/K636174.jpg");
  add_card( "@ura__ra", "./img/participants/ura__ra.png");
  add_card( "@sys9kdr", "./img/participants/sys9kdr.jpg");
  add_card( "@stormcat24", "./img/participants/stormcat24.jpeg");
  add_card( "@slouis214", "./img/participants/slouis214.gif");
  add_card( "@JNKMT", "./img/participants/JNKMT.jpg");
  add_card( "dlmasa", "./img/participants/dlmasa.jpg");
  add_card( "@tnamigata", "./img/participants/tnamigata.jpg");
  add_card( "yaboo", "./img/participants/yaboo.gif");
  add_card( "@ichi98q", "./img/participants/ichi98q.jpg");
  add_card( "@nin2hanzo", "./img/participants/nin2hanzo.jpeg");
  add_card( "@youchan", "./img/participants/youchan.jpg");
  add_card( "ogatamakoto0521", "./img/participants/ogatamakoto0521.jpg");
  add_card( "@mainya", "./img/participants/mainya.jpg");
  add_card( "@chakasaka9", "./img/participants/chakasaka9.jpg");
}

window.addEventListener("load", draw_canvas);
window.setTimeout(draw_canvas, 1000);

